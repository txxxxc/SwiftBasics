// 11.1 Mentorという名前のクラスを定義してください



/* 11.2 Chapter12で定義したMentorクラスに以下のプロパティを追加してください
    1. firstName
        種類：変数
        型：String
        初期値: ""
    2. lastName
        種類：変数
        型：String
        初期値: ""
    3. mentorName
        種類：変数
        型：String
        初期値: ""
    4. course
        種類：変数
        型：String
        初期値: ""
    4. season(期、例：12, 14など)
        種類：変数
        型：Int
        初期値: 0
 
※: MentorクラスはChapter13からコピペしてもらってOKです
*/


// 11.3 11.2で作ったMentorクラスを初期化して、プロパティに値を代入してください。
// mentor.mentorName = "tt"のような感じで代入できます。

/* 11.4 Chapter13で定義したMentorクラスに以下の関数を実装してください
    関数名：slackName
    機能：lastNameとmentorNameを"."でつなげてコンソールに出力する
*/

/* 例：
let mentor = Mentor()
mentor.lastName = "tanaka"
mentor.mentorName = "tt"
mentor.slackName() // コンソールに"tt.tanaka"と出力される
*/


// 11.5 Chapter11で定義したMentorクラスにfistName, lastName, mentorName, course, seasonを受け取るイニシャライザを実装してください

