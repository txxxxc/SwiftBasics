// 6.1 配列numbersの左から1つ目の値をコンソールに出力してください
let numbers = [1, 3, 5]


// 6.2 配列numbersの左から3つ目の値をコンソールに出力してください


// 6.3 配列coursesに"iPhone"をコンソールに追加してください
var courses = ["WebD", "WebS", "Android"]

