// 9.1 for文を使って配列coursesに格納されている値をコンソールに出力してください
var courses = ["iPhone", "Android", "WebD", "WebS", "Movie"]

// 9.2 レンジとfor文を使って1から10の値をコンソールに出力してください

