// 5.1 +演算子をつかってfirstNameとlastNameを連結してコンソールに出力してください。
let firstName = "Steve"
let lastName = "Jobs"


// 5.2 \()を使ってfirstName、lastNameを連結してコンソールに出力してください。


// 5.3 \()または+演算子を使ってnumberをCurrent year is の後にコンソールに出力してください
let number = 5
print("Current year is... ")
